import 'package:flutter/material.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
     
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}
class SplashScreen extends StatelessWidget{
     const SplashScreen({super.key});


     @override
     Widget build (BuildContext context){
      return Scaffold(
        body: Stack(
          children: [
            Container(
              color: const Color(0xFFFEBC2F),
            ),
            Positioned(
              top: 50,
              right: 50,
              child: Opacity(
                opacity: 0.2,
                child: Image.asset(
                  'assets/images/hamburger.png',
                  width: 100,
              
                ),
              ),
            ),
            Positioned(
              bottom: 50,
              left: 20,
              child: Opacity(
                opacity: 0.2,
                child: Image.asset('assets/images/hamburger.png',
                  width: 150,
                ),
              ),
            ),
            Center(
              child: Image.asset('assets/images/logotipo.png',
                width: 100,

              ),
            )
          ],
        ),
      );
    }
}